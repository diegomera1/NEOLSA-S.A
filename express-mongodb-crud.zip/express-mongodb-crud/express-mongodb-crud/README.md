# CRUD with Nodejs, Express and Mongodb
![](docs/screenshot.png)

