window.addEventListener('load',function(){
$('.toggle').click(function(){
    $('.formulario').animate({
        height: "toggle",
        'padding-top': 'toggle',
        'padding-bottom': 'toggle',
        opacity: 'toggle'
    }, "slow");
})
function registrar(){
    alert ('se dio un click');
    var email = document.getElementById('txtcorreo').value
    var contrasena = document.getElementById('txtcontra').value
    firebase.auth().createUserWithEmailAndPassword(email, contrasena).catch(function(error) {
        // Handle Errors here.
        var errorCode = error.code;
        var errorMessage = error.message;
        // ...
      });
}
    btngrabar.addEventListener('click',function(){
        
        //POST
        //PUT
        let url= `https://registro-60bb3.firebaseio.com/usuario/${txtusuario.value}.json`
        let cuerpo={Usuario: txtusuario.value, Contraseña: txtcontra.value, Correo: txtcorreo.value, Telefono: txtcel.value }
        
        
        fetch(url,{
            method:'PUT',
            body: JSON.stringify(cuerpo),
            headers:{
                'Content-Type':'application/json'
            }
        }).then(resultado=>{
            return resultado.json();
        })
        .then(resultado2=>{
            alert(resultado2.Usuario+"se ha Registrado")
            console.log(resultado2.Usuario)
        })
        .catch(error=>{
            console.log('No se ha añadido',error)
        })
    })
    
    

  

function observador(){
    firebase.auth().onAuthStateChanged(function(user) {
        if (user) {
            alert (" existe usuario");
          // User is signed in.
          var displayName = user.displayName;
          var email = user.email;
          var emailVerified = user.emailVerified;
          var photoURL = user.photoURL;
          var isAnonymous = user.isAnonymous;
          var uid = user.uid;
          var providerData = user.providerData;
          // ...
        } else {
          // User is signed out.
          // ...
          alert ("no existe usuario");
        }
      })
}
observador();

})







